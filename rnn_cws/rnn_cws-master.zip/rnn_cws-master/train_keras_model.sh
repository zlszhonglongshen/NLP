/home/escenter11/gym/anaconda/bin/python ./train_keras_model.py ./cws.info ./cws.data ./cws_keras_model ./keras_model_weights
