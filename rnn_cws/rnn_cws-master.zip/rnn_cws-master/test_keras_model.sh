/home/escenter11/gym/anaconda/bin/python ./test_keras_model.py ./cws.info ./cws_keras_model ./keras_model_weights ./dataset/msr_test.utf8 ./dataset/msr_test.utf8.cws
